// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	int num, fatorial, i;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &num);
	fatorial = num;
	
	for (i = 1; i < num; i++) {
		fatorial *= i;
	}
	
	printf ("Fatorial de %d eh %d\n", num, fatorial);
	
	return 0;
}
