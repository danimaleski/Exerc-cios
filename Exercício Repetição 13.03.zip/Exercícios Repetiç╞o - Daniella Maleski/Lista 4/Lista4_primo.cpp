// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	int num, div = 0, i = 1;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &num);
	
	while (i <= num) {
		if (num % i == 0) div++;	
		i++;
	}
	
	if (div == 2) printf ("PRIMO\n");
	else {
		printf ("NAO PRIMO\n");
	}
	
	return 0;
}
