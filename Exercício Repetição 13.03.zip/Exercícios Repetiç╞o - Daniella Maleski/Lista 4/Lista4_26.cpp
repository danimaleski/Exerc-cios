// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	int n, i ,j;
	
	for (i = 0; i < 10; i++) {
		printf ("Entre com um numero: ");
		scanf ("%d", &n);
		
		printf ("\n-----TABUADA DE %d-----\n", n);
		for (j = 1; j <= 10; j++) {
			printf ("%d x %d = %d\n", j, n, j * n);
		}
		printf ("\n");
	}
	
	return 0;
}
