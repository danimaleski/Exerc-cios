// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	float x;
	int i, negativo = 0;
	
	for (i = 0; i < 10; i++) {
		printf ("Digite um numero: ");
		scanf ("%f", &x);
		if (x < 0) negativo++;
	}
	
	printf ("Quantidade de numeros negativos: %d\n", negativo);
	
	return 0;
}
