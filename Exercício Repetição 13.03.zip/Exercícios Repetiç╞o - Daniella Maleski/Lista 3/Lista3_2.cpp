// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	float x, maior = 0;
	int i;
	
	for (i = 0; i < 5; i++) {
		printf ("Digite um numero: ");
		scanf ("%f", &x);
		if (x > maior) maior = x;
	}
	
	printf ("O maior numero eh: %.2f\n", maior);
	
	return 0;
}
