#include <stdio.h>

struct dados_alunos {
	char nome[100], matricula[100];
	float notas[4], media;
} aluno[3];

int main () {
	
	int i, x;
	
	for (x = 0; x < 3; x++) {
		float soma = 0; 
		
		printf ("Nome do aluno: ");
		scanf ("%s", &aluno[x].nome);
		
		printf ("Matricula de %s: ", aluno[x].nome);
		scanf ("%s", &aluno[x].matricula);
		
		printf ("Entre com as 4 notas:\n");
		for (i = 0; i < 4; i++) {
			printf ("Nota %d: ", i + 1);
			scanf ("%f", &aluno[x].notas[i]);
			soma += aluno[x].notas[i];
		}
		
		aluno[x].media = soma / 4.0;
		printf ("MEDIA DE %s: %.1f\n", aluno[x].nome, aluno[x].media);	
	}
	
	for (x = 0; x < 3; x++) {
		printf ("\nNOME: %s\n", aluno[x].nome);
		printf ("MATRICULA: %s\n", aluno[x].matricula);
		printf ("MEDIA: %.1f\n", aluno[x].media);
	}

	return 0;
}
