#include <stdio.h>

struct dados_alunos {
	char nome[100], matricula[100];
	float notas[4], media;
} aluno;

int main () {
	
	int i;
	float soma = 0; 
		
	printf ("Nome do aluno: ");
	scanf ("%s", &aluno.nome);
		
	printf ("Matricula de %s: ", aluno.nome);
	scanf ("%s", &aluno.matricula);
		
	printf ("Entre com as 4 notas:\n");
	for (i = 0; i < 4; i++) {
		printf ("Nota %d: ", i + 1);
		scanf ("%f", &aluno.notas[i]);
		soma += aluno.notas[i];
	}
		
	aluno.media = soma / 4.0;
	
	printf ("\nNOME: %s\n", aluno.nome);
	printf ("MATRICULA: %s\n", aluno.matricula);
	printf ("MEDIA: %.1f\n", aluno.media);

	return 0;
}
