#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//lISTA QUEST�O 5.

int main(void){
	
	int K[20], aux, i;
	
	for(i=0; i<20; i++){
		printf(" K[%d]: ",i);
		scanf("%d", &K[i]);
	}
	for(i=0; i<20; i++){
		printf("%d  ", K[i]);
		
	}
	for(i=0; i<20; i++){
				
		if (i%2==0){
			aux=K[i];
			K[i]=K[i+1];
			K[i+1]=aux;
		}
		
	}
	printf("\n");
	for(i=0; i<20; i++){
		printf("%d  ", K[i]);
		
	}
}
