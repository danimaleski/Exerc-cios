#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//lISTA QUEST�O 8.

int main(void){
	
	int X[10], i, j, cont=0;
	
	for(i=0; i<10; i++){
		printf(" X[%d]: ",i);
		scanf("%d",&X[i]);
			
	}
	for(i=0; i<10; i++){
		for(j=0; j<10; j++){
			if(X[i]==X[j]){
				cont++;
			}
		}
		
		if(cont>1){
			printf("O numero %d repetiu %d \n", X[i], cont);		
		}
		cont=0;
	}
	return 0;
}
