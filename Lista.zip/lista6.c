#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//lISTA QUEST�O 6.

int main(void){
	
	int L[7], i, x, n=0, j=6, tam=7, cont=0;
	
	for(i=0; i<7; i++){
		printf(" L[%d]: ",i);
		scanf("%d",&L[i]);
		//L[i]=i; para testar (automaticamente)
	}
	for(i=0; i<7; i++){
		printf("%d  ", L[i]);
		
	}
	printf("\nDigite o numero que deseja: ");
	scanf("%d", &x);
	
	while(n==0){
		j=j/2;
		if (L[j] < x){
			j=j+7;
		} 
		
		if (L[j] == x){
			n=1;
		}
		cont++;
		if(cont==tam){
			n=-1;
		}
	}
	if (n==1){
		printf("Achou o numero desejado");
	} else {
		printf("Nao achou o numero desejado");
	}
	
	
	
}

