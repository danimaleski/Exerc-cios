#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//lISTA QUEST�O 4.

int main(void){
	
	int N[20], aux, i;
	
	for(i=0; i<20; i++){
		printf(" N[%d]: ",i);
		scanf("%d",&N[i]);
	}
	for(i=0; i<20; i++){
		printf("%d  ", N[i]);
		
	}
	for(i=0; i<10; i++){
		aux=N[i];
		N[i]=N[19-i];
		N[19-i]=aux;
		
	}
	printf("\n");
	for(i=0; i<20; i++){
		printf("%d  ", N[i]);
		
	}
}
