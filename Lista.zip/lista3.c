#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//lISTA QUEST�O 3.

int main(void){
	
	int i, n=0, soma,perf=0;
	
	while(perf<5){
		
		for(i=1; i<n; i++){
			if(n%i==0){
			soma=soma+i;
				
			}
			
		} 
		if (soma==n){
			perf++;
			printf("\n%d", n);
		}
		soma=0;	
		n++;		
			
	}
	
	return 0;
}
	
