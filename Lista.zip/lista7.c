#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//lISTA QUEST�O 7.

int main(void){
	
	int A[9], B[9], C[9], D[9], i;
	
	for(i=0; i<9; i++){
		printf(" A[%d]: ",i);
		scanf("%d", &A[i]);
	}
	for(i=0; i<9; i++){
		printf(" B[%d]: ", i);
		scanf("%d", &B[i]);
	}
	for(i=0; i<9; i++){
		printf(" C[%d]: ", i);
		scanf("%d", &C[i]);
	}
	for(i=0; i<3; i++){
		D[i]=A[i];
		D[i+3]=B[i+3];
		D[i+6]=C[i+6];
				
	}
	for(i=0;i<9; i++){
		printf("\nPrimeiro vetor: %d", A[i]);
	}
	printf("\n");
	for(i=0; i<9; i++){
		printf("\nSegundo vetor: %d", B[i]);
	}
	printf("\n");
	for(i=0; i<9; i++){
		printf("\nTerceiro vetor: %d", C[i]);
	}
	printf("\n");
	for(i=0; i<9; i++){
		printf("\nVetor resultante: %d", D[i]);
	}	
	return 0;
}

