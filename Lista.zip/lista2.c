#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//LISTA QUEST�O 2. 

int main(void){
	
	int i, m=1, fat, cont, soma;
	cont=0;
	fat=1;
	
	while(m!=0){
		 
		printf("\nDigite algum valor: ");
		scanf("\n%d", &m);
		 
		if (m%2==0){
			
			for(i=1; i<=m; i++){
				if(m%i==0){
					cont++;
				} 	
			
			}
			printf("\nPossui %d divisores", cont);
			cont=0;
		} else {
			
			if ((m%2!=0) && (m<12)){
				
				for(i=1; i<=m; i++){
		
				fat = fat*i; 
				//calcular o fatorial
			}
			printf("\nFatorial: %d", fat);
			fat=1;
			}			
			if ((m%2!=0)&&(m>=12)){
					
				for(i=1; i<=m; i++){
					
					soma=soma+i;
					
				}
				printf("\nSoma dos valores: %d", soma);	
				soma=0;
			
			}
			
		}
	}
	return 0;
} 
