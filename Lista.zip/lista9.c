#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//lISTA QUEST�O 7.

int main(void){
	
	int M[20], i, j, aux;
	
	for(i=0;i<20;i++){
		printf("M[%d]: ", i);
		scanf("%d", &M[i]);
	}
	for(i=0;i<20;i++){
		for(j=0; j<19;j++){
			if(M[j]==0){
				aux=M[j];
				M[j]=M[j+1];
				M[j+1]=aux;
			}
			
		}
	}
	
	for(i=0;i<20;i++){
		printf( "%d ", M[i]);
		
	}
	
	return 0;
}
