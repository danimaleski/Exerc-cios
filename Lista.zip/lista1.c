#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//LISTA QUEST�O 1

int main(void){
	
	int f, i, n, j, p, div=0, k;
	f=0;
	n=0;
	j=1;
	for(i=1; i<=30; i++){
		f=n+j;
		n=j;
		j=f;
			
		for(k=1, div = 0; k<=f;k++){
			if (f%k==0) div++;
		}
		if (div==2)
		    printf("%d - PRIMO\n", f);
		else 
		   	printf("%d - NAO PRIMO\n", f);
	
	}
	return 0;
}
