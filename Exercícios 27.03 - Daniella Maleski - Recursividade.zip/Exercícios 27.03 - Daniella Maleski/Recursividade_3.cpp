// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int seq (int num) {
	
	if (num)
		return seq(num - 1) + 2;
	else return 1;
}

int main () {
	
	int num;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &num);
	
	printf ("Resultado: %d\n", seq(num));
	
	return 0;
}
