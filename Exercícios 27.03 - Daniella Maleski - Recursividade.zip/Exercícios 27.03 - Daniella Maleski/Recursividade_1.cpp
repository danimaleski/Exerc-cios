// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int fatorial (int num) {
	
	if (num)
		return num * fatorial(num - 1);
	else return 1;
}

int main () {
	
	int num;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &num);
	
	printf ("%d! = %d\n", num, fatorial(num));
	
	return 0;
}
