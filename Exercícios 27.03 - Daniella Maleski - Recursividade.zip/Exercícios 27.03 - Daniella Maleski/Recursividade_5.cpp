// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int soma (int num) {
	
	if (num)
		return num + soma(num - 1);
}

int main () {
	
	int num;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &num);
	
	printf ("A soma de 1 ate %d eh %d\n", num, soma(num));
	
	return 0;
}
