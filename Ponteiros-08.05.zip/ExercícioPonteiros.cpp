#include <stdio.h>

int ordenaVetor (int *vetor, int tam){
	int i, j, aux;
	for(i = 0; i < tam - 1; i++) {
 		for(j = i + 1; j < tam; j++) {
			if(vetor[i] > vetor[j]) {
				aux = vetor[i];
				vetor[i] = vetor[j];
				vetor[j] = aux;
			}
		}
	}
		
}

int leTamVetor(){
	int tam;
	printf ("Entre com o tamanho do vetor desejado: ");
	scanf ("%d", &tam);
	return tam;
}

void leValores(int *vetor, int *tam){
	printf ("\n\nEntre com %d numeros para o vetor:\n", *tam);
	int i;
	for (i = 0; i < *tam; i++) {
		scanf ("%d", &vetor[i]);
	}
	
}

int main(){
	
	int i, j, tam, soma = 0, aux;
	
	tam = leTamVetor();
	
	int vetor[tam];
	//int *vetor = (int *) malloc ( sizeof(int) * tam);
	
	//passagem por referencia do tam
	leValores(vetor, &tam);
	
	ordenaVetor(vetor, tam);
	
	printf ("\nVetor Ordenado:");
	for (i = 0; i < tam; i++) {
		printf ("  %d", vetor[i]);
	}	
	
}
