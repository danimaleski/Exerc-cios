// Developed by: Amanda Vicente and Daniella Maleski
#include <stdio.h>
#include <math.h>

float quadrado (float num) {
	return (pow(num, 2));
}

float fatorial (float num) {
	int i;
	float fatorial = num;
	
	for (i = 1; i < num; i++) {
		fatorial *= i;
	}
	
	return (fatorial);
}

float somatorio (float num) {
	int i;
	float soma = 0;
	
	for (i = 1; i <= num; i++) {
		soma += i;
	}
	
	return (soma);
}

int main () {
	
	float num;
	
	printf ("Informe um numero: ");
	scanf ("%f", &num);
	
	printf ("O seu quadrado: %.1f\n", quadrado(num));
	printf ("O seu fatorial: %.1f\n", fatorial(num));
	printf ("O seu somatorio: %.1f\n", somatorio(num));
	
	return 0;
}
