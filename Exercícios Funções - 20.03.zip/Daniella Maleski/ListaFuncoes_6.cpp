// Developed by: Amanda Vicente and Daniella Maleski
#include <stdio.h>

int produto (int a, int b);
int soma (int a, int b);
int diferenca (int a, int b);
int divisao (int a, int b);
void menu ();

int main () {
	
	int num1, num2, opcao;
	
	printf ("Informe dois numeros:\n");
	scanf ("%d", &num1);
	scanf ("%d", &num2);
	
	menu();
	scanf ("%d", &opcao);
	while (opcao != 5) {
		switch (opcao) {
			case 1:
				printf ("\nProduto: %d\n", produto(num1, num2));
				break;
			case 2:
				printf ("\nSoma: %d\n", soma(num1, num2));
				break;
			case 3:
				printf ("\nDiferenca: %d\n", diferenca(num1, num2));
				break;
			case 4:
				printf ("\nDivisao: %d\n", divisao(num1, num2));
				break;
		}
		menu();
		scanf ("%d", &opcao);
	}
	if (opcao == 5) printf ("\nSessao finalizada!\n");
	
	return 0;
}

void menu () {
	printf ("\n -----MENU------ \n");
	printf ("| 1 - Produto\t|\n");
	printf ("| 2 - Soma\t|\n");
	printf ("| 3 - Diferenca\t|\n");
	printf ("| 4 - Divisao\t|\n");
	printf ("| 5 - Sair\t|\n");
	printf (" --------------- \n");
	printf ("\nDigite o numero da opcao desejada:\n");
}

int produto (int a, int b) {
	return (a * b);
}

int soma (int a, int b) {
	return (a + b);
}

int diferenca (int a, int b) {
	return (a - b);
}

int divisao (int a, int b) {
	return (a / b);
}
