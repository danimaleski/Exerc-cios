// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>
#include <string.h>
#include <math.h>

int main () {
	
	char nome[500];
	float horas, porhora = 15, ir = 0.15, inss = 0.11, sind = 0.03, salb, saliq, IR, INSS, SIND;
	
	printf ("Funcionario: ");
	gets (nome);
	printf ("Horas trabalhadas do %s: ", nome);
	scanf ("%f", &horas);
	
	salb = horas * porhora;
	IR = salb * ir;
	INSS = salb * inss;
	SIND = salb * sind;
	saliq = salb - (IR + INSS + SIND);
	
	printf ("-----------------------------------\n");
	printf ("Salario Bruto\t\t :R$%.2f\n", salb);
	printf ("(-)IR\t\t(15%%)\t :R$%.2f\n", IR);
	printf ("(-)INSS\t\t(11%%)\t :R$%.2f\n", INSS);
	printf ("(-)Sindicato\t(3%%)\t :R$%.2f\n", SIND);
	printf ("Salario Liquido\t\t :R$%.2f\n", saliq);
	printf ("-----------------------------------\n");
	
	return 0;
}
