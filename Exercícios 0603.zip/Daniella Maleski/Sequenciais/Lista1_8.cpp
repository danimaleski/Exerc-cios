// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	float nota1, nota2, peso1, peso2, soma, mediap;
	
	printf ("Entre com a primeira nota: ");
	scanf ("%f", &nota1);
	printf ("Entre com o primeiro peso: ");
	scanf ("%f", &peso1);
	
	printf ("\nEntre com a segunda nota: ");
	scanf ("%f", &nota2);
	printf ("Entre com o segundo peso: ");
	scanf ("%f", &peso2);
	
	soma = peso1 + peso2;
	mediap = ((nota1 * peso1) + (nota2 * peso2)) / soma;
	
	printf ("\nA media ponderada foi de : %.2f\n", mediap);
	
	return 0;
}
