// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	char turno;
	
	printf ("Que turno voce estuda? : ");
	scanf ("%c", &turno);
	
	switch (turno) {
		case 'M':
			printf ("\n\tBom dia flor do dia :)\n");
		break;
		case 'V':
			printf ("\n\tBoa tarde raio de sol :)\n");
		break;
		case 'N':
			printf ("\n\tBoa noite luz do luar :)\n");
		break;
		default:
			printf ("\n\tTurno invalido.\n");
	}
	
	return 0;
}
