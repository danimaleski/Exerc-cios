// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	int dia;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &dia);
	
	if (dia == 1) {
		printf ("\n1 - DOMINGO");
	}
	else if (dia == 2) {
		printf ("\n2 - SEGUNDA");
	}
	else if (dia == 3) {
		printf ("\n3 - TERCA");
	}
	else if (dia == 4) {
		printf ("\n4 - QUARTA");
	}
	else if (dia == 5) {
		printf ("\n5 - QUINTA");
	}
	else if (dia == 6) {
		printf ("\n6 - SEXTA");
	}
	else if (dia == 7) {
		printf ("\n7 - SABADO");
	}
	else {
		printf ("\nDia de semana invalido.");
	}
	
	return 0;
}
