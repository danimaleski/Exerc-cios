// Developed by: Amanda Vicente and Daniella Maleski

#include <stdio.h>

int main () {
	
	int num;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &num);
	
	if (num % 2 == 0) {
		printf ("\t%d eh PAR!!\n", num);
	}
	else if (num % 2 != 0) {
		printf ("\t%d eh IMPAR!!\n", num);
	}
	
	return 0;
}
