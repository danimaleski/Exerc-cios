// Developed by: Amanda Vicente and Daniella Maleski
#include <stdio.h>
#include <stdlib.h>

int main () {
	
	int M[4][4], i, j, maior = -999, linha, coluna, menor;
	
	for(i = 0; i <= 3; i++){
		for(j = 0; j <= 3; j++){
			scanf("%d", &M[i][j]);
			if (M[i][j] > maior) {
				maior = M[i][j];
				linha = i;
			}
		}
	}
	
	menor = maior;
	
	printf ("\nMatriz 4x4: \n");
	for(i = 0; i <= 3; i++){
		for(j = 0; j <= 3; j++){
			if (j == 3) {
				printf ("%d\n", M[i][j]);
			}
			else {
				printf ("%d ", M[i][j]);
			}
		}
	}
	
	for (j = 0; j <= 3; j++) {
		if (M[linha][j] < menor) {
			menor = M[linha][j];
			coluna = j;
		}
	}
	
	printf ("\nMaior elemento: %d\n", maior);
	printf ("\nElemento MINIMAX:  %d\n", menor);
	printf ("\nPosicao:  M[%d][%d]\n", linha, coluna);
	
	return 0;
}
