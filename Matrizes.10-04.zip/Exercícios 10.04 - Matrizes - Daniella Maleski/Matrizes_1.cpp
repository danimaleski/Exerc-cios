// Developed by: Amanda Vicente and Daniella Maleski
#include <stdio.h>
#include <stdlib.h>

int main(){
	
	int vlinha[3], vcoluna[3], i, j, M[3][3], soma; 

	for(i = 0; i <= 2; i++){
		for(j = 0; j <= 2; j++){
			scanf("%d", &M[i][j]);
		}
	}
	
	printf ("\n\nMatriz 3x3: \n");
	for(i = 0; i <= 2; i++){
		for(j = 0; j <= 2; j++){
			if (j == 2) {
				printf("%d\n", M[i][j]);
			}
			else {
				printf("%d ", M[i][j]);
			}
		}
	}
	
	//Soma das linhas
	for(i = 0; i <= 2; i++){
		for(j = 0; j <= 2; j++){
			soma += M[i][j];
		}
		vlinha[i] = soma;
		soma = 0;
	}
	
	printf ("\nSoma das linhas da matriz: ");
	for (i = 0; i < 3; i++) {
		printf ("%d ", vlinha[i]);
	}
	
	//Soma das colunas
	for(j = 0; j <= 2; j++){
		for(i = 0; i <= 2; i++){
			soma += M[i][j];
		}
		vcoluna[j] = soma;
		soma = 0;
	}
	
	printf ("\n\nSoma das colunas da matriz: ");
	for (i = 0; i < 3; i++) {
		printf ("%d ", vcoluna[i]);
	}
	
	return 0;
}
