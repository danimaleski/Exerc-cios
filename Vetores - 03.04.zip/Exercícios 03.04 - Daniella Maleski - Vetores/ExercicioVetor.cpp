// Developed by: Amanda Vicente and Daniella Maleski
#include <stdio.h>

int main () {
	
	int i, j, tam, soma = 0, aux;
	
	printf ("Entre com o tamanho do vetor desejado: ");
	scanf ("%d", &tam);
	
	int vetor[tam];
	
	printf ("\n\nEntre com %d numeros para o vetor:\n", tam);
	for (i = 0; i < tam; i++) {
		scanf ("%d", &vetor[i]);
		soma += vetor[i];
	}
	
	//Ordenando o vetor
	for(i = 0; i < tam - 1; i++) {
 		for(j = i + 1; j < tam; j++) {
			if(vetor[i] > vetor[j]) {
				aux = vetor[i];
				vetor[i] = vetor[j];
				vetor[j] = aux;
			}
		}
	}
	
	printf ("\nVetor Ordenado:");
	for (i = 0; i < tam; i++) {
		printf ("  %d", vetor[i]);
	}
	
	printf ("\n\nA media do vetor: %.1f\n", ((float)soma/tam));

	
	return 0;
}
