// Developed by: Amanda Vicente and Daniella Maleski
#include <stdio.h>

int main () {
	
	int vetor[80], i = 0, menor = 99999, posicao;
	
	printf ("Entre com 80 valores: \n");
	for (i = 0; i < 80; i++) {
		scanf ("%d", &vetor[i]);
		if (vetor[i] < menor) {
			menor = vetor[i];
			posicao = i;
		}
	}
	
	printf ("\n\nO menor elemento eh %d e sua posicao eh %d\n", menor, posicao);
	
	return 0;
}
