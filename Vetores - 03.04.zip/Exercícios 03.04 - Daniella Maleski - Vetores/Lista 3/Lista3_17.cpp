// Developed by: Amanda Vicente and Daniella Maleski
#include <stdio.h>

int main () {
	
	int vetor1[10], vetor2[10], soma[10], diferenca[10], i;
	
	printf ("Entre com 10 valores para o primeiro vetor: \n");
	for (i = 0; i < 10; i++) {
		scanf ("%d", &vetor1[i]);
	}
	
	printf ("\n\nEntre com 10 valores para o segundo vetor: \n");
	for (i = 0; i < 10; i++) {
		scanf ("%d", &vetor2[i]);
	}
	
	printf ("\n\nO primeiro vetor:");
	for (i = 0; i < 10; i++) {
		printf ("  %d", vetor1[i]);
	}
	
	printf ("\n\nO segundo vetor:");
	for (i = 0; i < 10; i++) {
		printf ("  %d", vetor2[i]);
	}
	
	printf ("\n\n\n\nA soma entre os dois vetores:");
	for (i = 0; i < 10; i++) {
		soma[i] = vetor1[i] + vetor2[i];
		printf ("  %d", soma[i]);
	}
	
	printf ("\n\nA diferenca entre os dois vetores:");
	for (i = 0; i < 10; i++) {
		diferenca[i] = vetor1[i] - vetor2[i];
		printf ("  %d", diferenca[i]);
	}
	
	return 0;
}
